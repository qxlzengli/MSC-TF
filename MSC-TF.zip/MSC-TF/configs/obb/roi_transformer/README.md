# [Learning RoI Transformer for Oriented Object Detection in Aerial Images](https://openaccess.thecvf.com/content_CVPR_2019/papers/Ding_Learning_RoI_Transformer_for_Oriented_Object_Detection_in_Aerial_Images_CVPR_2019_paper.pdf#:~:text=The%20core%20idea%20of%20RoI%20Transformer%20is%20to,embed-%20ded%20into%20detectors%20for%20oriented%20object%20detection.)

## Introduction
```
@inproceedings{RN8,
	author = {Ding, Jian and Xue, Nan and Long, Yang and Xia, Gui-Song and Lu, Qikai},
	title = {Learning RoI Transformer for Oriented Object Detection in Aerial Images},
	publisher = {IEEE},
	DOI = {10.1109/cvpr.2019.00296},
	url = {https://dx.doi.org/10.1109/cvpr.2019.00296},
	type = {Conference Proceedings}
}
```

## Results and models

to be continue!!!
