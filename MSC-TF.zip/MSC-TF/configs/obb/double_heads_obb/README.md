# Rethinking Classification and Localization for Object Detection

## Introduction

Oriented form of double head model

```
@article{wu2019rethinking,
    title={Rethinking Classification and Localization for Object Detection},
    author={Yue Wu and Yinpeng Chen and Lu Yuan and Zicheng Liu and Lijuan Wang and Hongzhi Li and Yun Fu},
    year={2019},
    eprint={1904.06493},
    archivePrefix={arXiv},
    primaryClass={cs.CV}
}
```

## Results and models
to be continue !
